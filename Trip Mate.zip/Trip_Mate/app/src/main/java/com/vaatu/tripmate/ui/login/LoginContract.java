package com.vaatu.tripmate.ui.login;

/**
 * Defines the contract between the View {@link LoginActivity} and the Presenter {@link LoginPresenter}
 */
public interface LoginContract {

    interface MvpView{


    }
    interface MvpPresenter{


    }

}
